<?php 
session_start();

$_SESSION["username"] = "faisal";
$_SESSION["password"] = "123";


 ?>

 <a href="login.php">login</a>